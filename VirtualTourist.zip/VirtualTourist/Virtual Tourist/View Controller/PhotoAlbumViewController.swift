//
//  PhotoAlbumViewController.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 04/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import MapKit

class PhotoAlbumViewController: UICollectionViewController, NSFetchedResultsControllerDelegate {
    
    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<Picture>!
    var pin: Pin!
    var pictures: [Photos]? = []

    
    func setUpFetchedResultsController() {
        let fetchRequest: NSFetchRequest<Picture> = Picture.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "id", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController.delegate = self

        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addButton()
        collectionView.register(PhotoCollectionViewCell.self, forCellWithReuseIdentifier: "pictureCell")
        
        setUpFetchedResultsController()
        
        FlickrAPI.getPhotosFromFlickr(latitude: pin.latitude, longitude: pin.longitude) { (photos, error) in
            if photos != nil {
                self.pictures = photos?.photos.photo
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            } else {
                print("download failed")
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        setUpFetchedResultsController()
        
        print("viewWillAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        fetchedResultsController = nil
    }
    
    @IBAction func reloadPhotos(_ sender: Any) {
    }
    
    //MARK: Present data in a collection view form
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
      return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        print("setting up view")
        
        if let numberOfPictures = self.pictures?.count {
            return numberOfPictures
        } else {
            addLabel()
            return 0
        }
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "pictureCell", for: indexPath) as! PhotoCollectionViewCell

        if let pictures = self.pictures?[(indexPath as NSIndexPath).row] {
            let url = URL(string: pictures.urlN)
            print(url)
            FlickrAPI.getPhoto(url: url!) { (image, error) in
                if error != nil {
                    print("error")
                }
                DispatchQueue.main.async {
                    cell.photoImageView?.image = image
                }
            }
        }
        return cell
    }

//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//
//        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
//        detailController.memes = self.memes[(indexPath as NSIndexPath).row]
//        self.navigationController!.pushViewController(detailController, animated: true)
//
//    }
    
    func addButton() -> UIButton {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("NEW COLLECTION", for: UIControl.State.normal)
        button.setTitleColor(UIColor.white, for: UIControl.State.normal)
        self.view.addSubview(button)
        button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        button.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        button.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        return button
    }
    
    func addLabel() {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        label.center = CGPoint(x: 160, y: 285)
        label.textAlignment = .center
        label.text = "No images found"
        self.view.addSubview(label)
    }
    
}
