//
//  PhotoAlbumViewController.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 04/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import MapKit

class PhotoAlbumViewController: UICollectionViewController, NSFetchedResultsControllerDelegate {
    
    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<Picture>!
    var pin: Pin!
    var pictures: [Photos]?
    
    @IBOutlet weak var mapView: MKMapView!
    
    func setUpFetchedResultsController() {
        let fetchRequest: NSFetchRequest<Picture> = Picture.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "id", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController.delegate = self

        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let pinToDisplay = MKPointAnnotation()
        pinToDisplay.coordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees(pin.latitude), longitude: CLLocationDegrees(pin.longitude))
        mapView.addAnnotation(pinToDisplay)
        
        let centerCoordinates = pinToDisplay.coordinate
        mapView.setCenter(centerCoordinates, animated: true)
        
        
        setUpFetchedResultsController()
        FlickrAPI.getPhotosFromFlickr(latitude: pin.latitude, longitude: pin.longitude) { (photos, error) in
            if photos != nil {
                self.pictures = photos?.photos.photo
                print(self.pictures)
            } else {
                print("download failed")
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        setUpFetchedResultsController()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        fetchedResultsController = nil
    }
    
    @IBAction func reloadPhotos(_ sender: Any) {
    }
    
    //MARK: Present data in a collection view form
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        if let numberOfPictures = self.pictures?.count {
//            return numberOfPictures
//        } else {
//            //Call a function to display a label that nothing exists
//            return 0
//        }
        return 1
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "pictureCell", for: indexPath) as! PhotoCollectionViewCell

//        if let pictures = self.pictures?[(indexPath as NSIndexPath).row] {
//            let url = URL(string: pictures.urlN)
//            print(url)
//            FlickrAPI.getPhoto(url: url!) { (image, error) in
//                if error != nil {
//                    print("error")
//                }
//                DispatchQueue.main.async {
//                    cell.photoImageView?.image = image
//                }
//            }
//        }
        
        return cell
        
    }

//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//
//        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
//        detailController.memes = self.memes[(indexPath as NSIndexPath).row]
//        self.navigationController!.pushViewController(detailController, animated: true)
//
//    }
    
}
