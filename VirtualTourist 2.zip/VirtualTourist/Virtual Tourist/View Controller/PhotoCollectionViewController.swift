//
//  PhotoCollectionViewController.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 11/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class PhotoCollectioNViewController: UICollectionViewController {
    
}
