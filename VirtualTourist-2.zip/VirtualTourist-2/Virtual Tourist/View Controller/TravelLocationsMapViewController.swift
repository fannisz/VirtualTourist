//
//  TravelLocationsMapViewController.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 02/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreData

class TravelLocationsMapViewController: UIViewController, NSFetchedResultsControllerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<Pin>!
    
    func setUpFetchedResultsController() {
        let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "longitude", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "pins")
        fetchedResultsController.delegate = self

        do {
            try fetchedResultsController.performFetch()
            if fetchedResultsController.fetchedObjects?.count == 0 {
                print("No pins existing")
            } else {
                let pins = fetchedResultsController.fetchedObjects!
                var placePins = [MKPointAnnotation()]
                for pin in pins {
                    let placePin = MKPointAnnotation()
                    placePin.coordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees(pin.latitude), longitude: CLLocationDegrees(pin.longitude))
                    placePins.append(placePin)
                }
                DispatchQueue.main.async {
                    self.mapView.addAnnotations(placePins)
                }
            }
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpFetchedResultsController()
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(TravelLocationsMapViewController.mapLongPress(_:)))
        longPress.minimumPressDuration = 1
        mapView.addGestureRecognizer(longPress)
        //Set defaults
        if let centerLatitude = UserDefaults.standard.value(forKey: "mapCenterLatitude") {
            if let centerLongitude = UserDefaults.standard.value(forKey: "mapCenterLongitude") {
                let centerPreference = CLLocationCoordinate2D(latitude: centerLatitude as! CLLocationDegrees, longitude: centerLongitude as! CLLocationDegrees)
                mapView.setCenter(centerPreference, animated: true)
            }
            print("first launch")
        } else {
            print("First launch")
        }
        if let latitudeDelta = UserDefaults.standard.value(forKey: "zoomLatitude") {
            let centerLatitude = UserDefaults.standard.value(forKey: "mapCenterLatitude")
            let centerLongitude = UserDefaults.standard.value(forKey: "mapCenterLongitude")
            let centerPreference = CLLocationCoordinate2D(latitude: centerLatitude as! CLLocationDegrees, longitude: centerLongitude as! CLLocationDegrees)
            let longitudeDelta = UserDefaults.standard.value(forKey: "zoomLongitude")
            let span: MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: latitudeDelta as! CLLocationDegrees, longitudeDelta: longitudeDelta as! CLLocationDegrees)
            let region: MKCoordinateRegion = MKCoordinateRegion(center: centerPreference, span: span)
            mapView.setRegion(region, animated: true)
        } else {
            print("No zoom level yet")
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        setUpFetchedResultsController()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        fetchedResultsController = nil

        //Prepare UserDefault for center coordinates
        let centerLatitude = Float(mapView.centerCoordinate.latitude)
        let centerLongitude = Float(mapView.centerCoordinate.longitude)
        UserDefaults.standard.set(centerLatitude, forKey: "mapCenterLatitude")
        UserDefaults.standard.set(centerLongitude, forKey: "mapCenterLongitude")

        //Prepare UserDefault for zoom level
        let span: MKCoordinateSpan = mapView.region.span
        let latitudeDelta = Float(span.latitudeDelta)
        let longitudeDelta = Float(span.longitudeDelta)
        UserDefaults.standard.set(latitudeDelta, forKey: "zoomLatitude")
        UserDefaults.standard.set(longitudeDelta, forKey: "zoomLongitude")
    }


    //MARK: Implement delegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {

        let reuseId = "pin"

        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = false
            pinView!.pinTintColor = .red
        }
        else {
            pinView!.annotation = annotation
        }

        return pinView
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let controller = storyboard?.instantiateViewController(withIdentifier: "PhotoAlbumViewController") as! PhotoAlbumViewController
        if let pins = fetchedResultsController.fetchedObjects {
            let annotation = mapView.selectedAnnotations[0]
            guard let indexPath = pins.firstIndex(where: { (pin) -> Bool in
                pin.latitude == Float(annotation.coordinate.latitude) && pin.longitude == Float(annotation.coordinate.longitude)
            }) else {
                return
            }
            controller.pin = pins[indexPath]
            controller.dataController = dataController
        }
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    //MARK: Implement @objc
    @objc func mapLongPress(_ recognizer: UIGestureRecognizer) {

        let touchedAt = recognizer.location(in: self.mapView)
        let touchedAtCoordinate : CLLocationCoordinate2D = mapView.convert(touchedAt, toCoordinateFrom: self.mapView)
        
        let pinData = Pin(context: dataController.viewContext)
        pinData.latitude = Float(touchedAtCoordinate.latitude)
        pinData.longitude = Float(touchedAtCoordinate.longitude)

        let newPin = MKPointAnnotation()
        newPin.coordinate = touchedAtCoordinate
        mapView.addAnnotation(newPin)
        do {
            try dataController.viewContext.save()
        } catch {
            debugPrint(error)
        }
    }    
}
