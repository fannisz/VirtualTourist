//
//  FlickrAPI.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 06/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class FlickrAPI {
    
    enum Endpoints {
        static let APIKey = "api_key=9596476c85a5085b44a82bad4a633500"
        static let base = "https://api.flickr.com/services/rest?"
        static let photoSearch = "method=flickr.photos.search"
        static let extras = "extras=url_n&format=json&safe_search=1&nojsoncallback=1"
        static let bBox = "bbox="
        static var minimumLongitude: Float = 0
        static var minimumLatitude: Float = 0
        static var maximumLongitude: Float = 0
        static var maximumLatitude: Float = 0
        static var coordinates = String(Endpoints.minimumLongitude) + "," + String(Endpoints.minimumLatitude) + "," + String(Endpoints.maximumLongitude) + "," + String(Endpoints.maximumLatitude)
        
        case getPhotos
        
        var stringValue: String {
            switch self {
            case .getPhotos:
                return Endpoints.base + Endpoints.photoSearch + "&" + Endpoints.APIKey + "&" + Endpoints.extras + "&" +  Endpoints.bBox + Endpoints.coordinates
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
        
    }
    
    class func getPhotosFromFlickr(latitude: Float, longitude: Float, completion: @escaping (PhotosResponse?, Error?) -> Void) {
        FlickrAPI.Endpoints.minimumLatitude = latitude - 1
        FlickrAPI.Endpoints.minimumLongitude = longitude - 1
        FlickrAPI.Endpoints.maximumLatitude = latitude + 1
        FlickrAPI.Endpoints.maximumLongitude = longitude + 1
        print(Endpoints.getPhotos.url)
        var request = URLRequest(url: Endpoints.getPhotos.url)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                completion(nil, error)
            }
            let decoder = JSONDecoder()
            do {
                let pictureData = try decoder.decode(PhotosResponse.self, from: data!)
                completion(pictureData, nil)
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    class func getPhoto(url: URL, completion: @escaping (UIImage?, Error?) -> Void) {
        let request = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (picture, response, error) in
            guard let picture = picture else {
                completion(nil, error)
                return
            }
            let downloadedImage = UIImage(data: picture)
            completion(downloadedImage, nil)
        }
        task.resume()
    }
    
}

