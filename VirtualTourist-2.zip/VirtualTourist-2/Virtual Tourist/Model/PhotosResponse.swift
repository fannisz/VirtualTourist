//
//  PhotosResponse.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 08/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class PhotosResponse: Codable {
    
    let photos: PhotosSecondLayer
    let stat: String
    
    enum CodingKeys: String, CodingKey {
        case photos
        case stat
    }
    
}

class PhotosSecondLayer: Codable {
    
    let photo: [Photos]
    
    enum CodingKeys: String, CodingKey {
        case photo
    }
    
}

class Photos: Codable {
    
    let id: String
    let urlN: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case urlN = "url_n"
    }
    
}
